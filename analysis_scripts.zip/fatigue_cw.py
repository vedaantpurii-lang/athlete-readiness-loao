import os
import sys, json, warnings, numpy as np, pandas as pd
pass
warnings.filterwarnings('ignore')
src=open(os.path.join(os.path.dirname(os.path.abspath(__file__)),'selected_eval.py')).read().split("out={}")[0]
exec(src)
res={}
for t,kw in [('fatigue',dict(max_depth=10,n_estimators=100)),('readiness',dict(max_depth=10,n_estimators=200))]:
    c=dict(CFG[t]); tr,te=load(t,'train'),load(t,'test'); y=te[c['tgt']].astype(int).values
    for cw in [None,'balanced']:
        rows=[]
        for sd in range(30):
            F=fsets(tr); num,cat=F[c['fs']]
            m=RandomForestClassifier(random_state=sd,class_weight=cw,**kw)
            p=pipe(num,cat,m).fit(tr[num+cat],tr[c['tgt']].astype(int))
            s=p.predict_proba(te[num+cat])[:,list(p.named_steps['m'].classes_).index(1)]
            rows.append(cm(y,(s>=.5).astype(int),s))
        df=pd.DataFrame(rows); res[f'{t}_{cw}']={k:(round(float(df[k].mean()),3),round(float(df[k].std()),3)) for k in df}
        print(t,cw,res[f'{t}_{cw}'],flush=True)
json.dump(res,open('class_weight.json','w'),indent=1)
