import os
import json, warnings, numpy as np, pandas as pd
from sklearn.base import clone
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.metrics import accuracy_score, balanced_accuracy_score, roc_auc_score, mean_absolute_error, mean_squared_error, r2_score
from scipy.stats import spearmanr
warnings.filterwarnings('ignore')
D=os.environ.get('DATA_DIR','Derived/')
OBJ=["sleep_onset_hours","sleep_offset_hours","total_sleep_time","sleep_intervals","longest_interval_duration","sleep period mean","sleep period standard deviation","sleep period msd"]
SUBJ=["sleepquality","sleepdura_sr"]; CN=["caffeine_mg","cola","coffee","tea","espresso"]; CC=["caffeine_time","screentime","matchday","weekday"]
def fsets(f):
    h=["day_index"]+[c for c in f.columns if c.startswith("prev_")]+[c for c in f.columns if c.startswith("roll3_")]
    return {"history_plus_all_sleep_context":(h+OBJ+SUBJ+CN,CC),"current_sleep_context":(OBJ+SUBJ+CN+["day_index"],CC)}
def load(t,s):
    d=pd.read_csv(D+f'{t}_{s}.csv'); d['coffee']=d['coffee'].replace('4 or more',4).astype(float)
    if 'handgrip_kg' in d: d['handgrip_kg']=pd.to_numeric(d['handgrip_kg'].astype(str).str.replace(',','.'),errors='coerce')
    return d
def pipe(num,cat,model):
    pre=ColumnTransformer([("n",Pipeline([("i",SimpleImputer(strategy="median")),("s",StandardScaler())]),list(num)),
        ("c",Pipeline([("i",SimpleImputer(strategy="most_frequent")),("e",OneHotEncoder(handle_unknown="ignore",sparse_output=False))]),list(cat))],remainder="drop")
    return Pipeline([("p",pre),("m",model)])
CFG={'readiness':dict(tgt='readiness_high',fs='history_plus_all_sleep_context',kw=dict(max_depth=10,n_estimators=200),cls=True),
     'fatigue':dict(tgt='fatigue_high',fs='history_plus_all_sleep_context',kw=dict(max_depth=10,n_estimators=100),cls=True),
     'handgrip':dict(tgt='handgrip_kg',fs='current_sleep_context',kw=dict(max_depth=1,n_estimators=10),cls=False)}
def cm(y,p,s):
    return dict(acc=accuracy_score(y,p),bal_acc=balanced_accuracy_score(y,p),auc=roc_auc_score(y,s) if len(np.unique(y))>1 else np.nan)
def rm(y,p):
    return dict(mae=mean_absolute_error(y,p),rmse=mean_squared_error(y,p)**.5,r2=r2_score(y,p),spearman=float(spearmanr(y,p)[0]))
def fit_pred(c,tr,te,seed):
    F=fsets(tr); num,cat=F[c['fs']]
    m=(RandomForestClassifier if c['cls'] else RandomForestRegressor)(random_state=seed,**c['kw'])
    p=pipe(num,cat,m).fit(tr[num+cat],tr[c['tgt']].astype(int if c['cls'] else float))
    X=te[num+cat]
    if c['cls']:
        cl=list(p.named_steps['m'].classes_); s=p.predict_proba(X)[:,cl.index(1)]; return (s>=0.5).astype(int),s
    v=p.predict(X); return v,v
out={}
rng=np.random.default_rng(0)
for t,c in CFG.items():
    tr,te=load(t,'train'),load(t,'test')
    if not c['cls']: tr=tr.dropna(subset=[c['tgt']]); te=te.dropna(subset=[c['tgt']])
    y=te[c['tgt']].values
    # (a) seed variability on the fixed split
    rows=[]
    for sd in range(30):
        p,s=fit_pred(c,tr,te,sd); rows.append(cm(y.astype(int),p,s) if c['cls'] else rm(y,p))
    df=pd.DataFrame(rows); out[t+'_seeds']={k:(float(df[k].mean()),float(df[k].std()),float(df[k].min()),float(df[k].max())) for k in df}
    # (b) athlete-level bootstrap on test athletes, seed 42 predictions
    p,s=fit_pred(c,tr,te,42); ids=te.id.values; ua=np.unique(ids); bs=[]
    for _ in range(2000):
        pick=rng.choice(ua,len(ua)); idx=np.concatenate([np.where(ids==a)[0] for a in pick])
        if c['cls'] and len(np.unique(y[idx]))<2: continue
        try: bs.append(cm(y[idx].astype(int),p[idx],s[idx]) if c['cls'] else rm(y[idx],p[idx]))
        except Exception: pass
    b=pd.DataFrame(bs); out[t+'_boot_test']={k:(float(b[k].quantile(.025)),float(b[k].quantile(.975))) for k in b}
    out[t+'_seed42_test']=cm(y.astype(int),p,s) if c['cls'] else rm(y,p)
    # (c) pooled leave-one-athlete-out over ALL athletes (train+test), fixed configuration
    al=pd.concat([tr,te],ignore_index=True); ya=al[c['tgt']].values; ia=al.id.values
    pp=np.zeros(len(al)); ss=np.zeros(len(al))
    for a in np.unique(ia):
        m=ia==a; pr,sc=fit_pred(c,al[~m].reset_index(drop=True),al[m].reset_index(drop=True),42); pp[m]=pr; ss[m]=sc
    base=np.zeros(len(al))
    for a in np.unique(ia):
        m=ia==a
        base[m]=(int(al.loc[~m,c['tgt']].mean()>=.5) if c['cls'] else al.loc[~m,c['tgt']].mean())
    ua=np.unique(ia); bs=[];bb=[]
    for _ in range(2000):
        pick=rng.choice(ua,len(ua)); idx=np.concatenate([np.where(ia==a)[0] for a in pick])
        if c['cls'] and len(np.unique(ya[idx]))<2: continue
        if c['cls']: bs.append(cm(ya[idx].astype(int),pp[idx].astype(int),ss[idx])); bb.append(cm(ya[idx].astype(int),base[idx].astype(int),base[idx]))
        else: bs.append(rm(ya[idx],pp[idx])); bb.append(rm(ya[idx],base[idx]) if np.std(base[idx])>0 else {})
    b=pd.DataFrame(bs); bbd=pd.DataFrame(bb)
    est=cm(ya.astype(int),pp.astype(int),ss) if c['cls'] else rm(ya,pp)
    bst=(cm(ya.astype(int),base.astype(int),base) if c['cls'] else rm(ya,base))
    out[t+'_allLOAO']=dict(n_athletes=int(len(ua)),n_rows=int(len(al)),model=est,baseline=bst,model_ci={k:(float(b[k].quantile(.025)),float(b[k].quantile(.975))) for k in b})
json.dump(out,open('selected_eval.json','w'),indent=1,default=float)
def show(d,ind=0):
    for k,v in d.items():
        if isinstance(v,dict): print(' '*ind+k); show(v,ind+2)
        elif isinstance(v,(tuple,list)): print(' '*ind+k+': '+', '.join(f'{x:.3f}' for x in v))
        else: print(' '*ind+f'{k}: {v:.3f}' if isinstance(v,float) else ' '*ind+f'{k}: {v}')
show(out)
