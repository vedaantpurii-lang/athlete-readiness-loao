import os
import json, warnings, sys
import numpy as np, pandas as pd
from sklearn.metrics import (accuracy_score, balanced_accuracy_score, roc_auc_score, f1_score,
                             precision_score, recall_score, mean_absolute_error, mean_squared_error, r2_score)
from scipy.stats import spearmanr
warnings.filterwarnings('ignore')
D=os.environ.get('DATA_DIR','Derived/')
TASKS={'readiness':('readiness_high','prev_readiness',7),'fatigue':('fatigue_high','prev_fatigue',3)}
def load(t,s):
    df=pd.read_csv(D+f'{t}_{s}.csv')
    if 'handgrip_kg' in df: df['handgrip_kg']=pd.to_numeric(df['handgrip_kg'].astype(str).str.replace(',','.'),errors='coerce')
    return df.sort_values(['id','day_index']).reset_index(drop=True) if 'day_index' in df else df
def cls_metrics(y,p,s=None):
    out=dict(acc=accuracy_score(y,p),bal_acc=balanced_accuracy_score(y,p),f1=f1_score(y,p,zero_division=0),
             prec=precision_score(y,p,zero_division=0),rec=recall_score(y,p,zero_division=0))
    out['auc']=roc_auc_score(y,s) if s is not None and len(np.unique(y))>1 else 0.5
    return out
def baselines_cls(train,test,tgt,prev,cut):
    maj=int(train[tgt].mean()>=0.5)
    y=test[tgt].astype(int).values
    res={}
    res['majority']=cls_metrics(y,np.full(len(y),maj),np.full(len(y),float(maj)))
    pv=test[prev].values
    missing=np.isnan(pv)
    pred=np.where(missing,maj,(pv>=cut).astype(int)); score=np.where(missing,train[tgt].mean(),pv)
    res['previous_day']=cls_metrics(y,pred,score)
    res['n_missing_prev']=int(missing.sum())
    return res
def reg_metrics(y,p):
    return dict(mae=mean_absolute_error(y,p),rmse=mean_squared_error(y,p)**0.5,r2=r2_score(y,p),
                spearman=float(spearmanr(y,p)[0]) if np.std(p)>1e-9 else float('nan'))
out={}
# ---- held-out test
for t,(tgt,prev,cut) in TASKS.items():
    tr,te=load(t,'train'),load(t,'test')
    out[f'{t}_test']=baselines_cls(tr,te,tgt,prev,cut)
tr,te=load('handgrip','train'),load('handgrip','test')
tr=tr.dropna(subset=['handgrip_kg']);te=te.dropna(subset=['handgrip_kg'])
out['handgrip_test']={'train_mean':reg_metrics(te.handgrip_kg.values,np.full(len(te),tr.handgrip_kg.mean()))}
out['handgrip_test']['train_mean_value']=float(tr.handgrip_kg.mean())
# ---- LOAO CV on training partition (pooled predictions, same protocol)
for t,(tgt,prev,cut) in TASKS.items():
    tr=load(t,'train'); y=tr[tgt].astype(int).values; g=tr.id.values
    pm=np.zeros(len(tr),int); pp=np.zeros(len(tr),int); ps=np.zeros(len(tr))
    majfix=int(tr[tgt].mean()>=0.5)
    for a in np.unique(g):
        m=g==a; maj=int(tr.loc[~m,tgt].mean()>=0.5); pm[m]=majfix
        pv=tr.loc[m,prev].values; miss=np.isnan(pv)
        pp[m]=np.where(miss,maj,(pv>=cut).astype(int)); ps[m]=np.where(miss,tr.loc[~m,tgt].mean(),pv)
    out[f'{t}_cv']={'majority':cls_metrics(y,pm,pm.astype(float)),'majority_value':majfix,'previous_day':cls_metrics(y,pp,ps)}
tr=load('handgrip','train').dropna(subset=['handgrip_kg']); y=tr.handgrip_kg.values; g=tr.id.values
p=np.zeros(len(tr))
for a in np.unique(g): m=g==a; p[m]=y[~m].mean()
p_const=np.full(len(y),y.mean())
out['handgrip_cv']={'loao_fold_mean':reg_metrics(y,p),'train_mean_constant':reg_metrics(y,p_const)}
json.dump(out,open('baselines.json','w'),indent=1,default=float)
def show(d,ind=0):
    for k,v in d.items():
        if isinstance(v,dict): print(' '*ind+k); show(v,ind+2)
        else: print(' '*ind+f'{k}: {round(v,3) if isinstance(v,float) else v}')
show(out)
